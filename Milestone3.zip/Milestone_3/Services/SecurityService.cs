﻿using CST_350_Milestone.Models;
using RegisterAndLoginApp.Models;

namespace CST_350_Milestone.Services
{
    public class SecurityService
    {
        List<UserModel> knownUsers = new List<UserModel>();

        public SecurityService()
        {

            knownUsers.Add(new UserModel { Id = 0, UserName = "Luwam", Password = "Password!" });
        }
        public bool IsValid(RegisterModel user)
        {
            return knownUsers.Any(x => x.UserName == user.Username && x.Password == user.Password);

        }
    }
}
