﻿using CST_350_Milestone.Models;
using CST_350_Milestone.Services;
using Microsoft.AspNetCore.Mvc;

namespace CST_350_Milestone.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly RegDBContext _context;
        private readonly SecurityDAO _securityDAO;

        public RegistrationController(RegDBContext context, SecurityDAO securityDAO)
        {
            _context = context;
            _securityDAO = securityDAO;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ShowRegistrationDetails(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                bool success = _securityDAO.InsertUser(model);

                if (success)
                {
                    return RedirectToAction("Index", "Home");  // Pass the model to the view
                }
                else
                {
                    ModelState.AddModelError("", "User registration failed. Please try again.");
                }
            }
            return View("Index", model);
        }

    }
}
