﻿using CST_350_Milestone.Models;
using CST_350_Milestone.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CST_350_Milestone.Controllers
{
    public class MinesweeperController : Controller
    {
        // The MinesweeperService instance is injected via the constructor
        private readonly MinesweeperService _minesweeperService;

        // Constructor for the controller which accepts the MinesweeperService
        public MinesweeperController(MinesweeperService minesweeperService)
        {
            _minesweeperService = minesweeperService;
        }

        // Default action that serves the Minesweeper board view
        public IActionResult Index()
        {
            // Create a new Minesweeper board
            var model = _minesweeperService.CreateBoard(10, 10, 20);
           
            return View(model);
        }

        // This action is called when a cell is clicked to reveal its content
        [HttpPost]
        public IActionResult RevealCell(int x, int y)
        {
            // Retrieve the current board from the session
            var model = GetCurrentBoard();
            _minesweeperService.RevealCell(model, x, y);
            
            // Return data about the revealed cell and the current game state to the frontend
            return Json(new
            {
                cellData = new
                {
                    isRevealed = model.Cells[x, y].IsRevealed,
                    isMine = model.Cells[x, y].IsMine,
                    neighboringMines = model.Cells[x, y].NeighboringMines
                },
                gameOver = model.GameOver,
                playerWon = model.PlayerWon
            });
        }

        // Retrieves the current board from the session or creates a new one if none exists
        private MinesweeperModel GetCurrentBoard()
        {
            if (this.HttpContext.Session.Get<MinesweeperModel>("CurrentBoard") == null)
            {
                var newBoard = _minesweeperService.CreateBoard(10, 10, 20);
                this.HttpContext.Session.Set("CurrentBoard", newBoard);
                return newBoard;
            }
            return this.HttpContext.Session.Get<MinesweeperModel>("CurrentBoard");
        }

        // An action that serves the board partial view. This could be used for refreshing the board on the frontend.
        [HttpGet]
        public IActionResult GetBoardPartial()
        {
            var model = GetCurrentBoard();
            return PartialView("_BoardPartial", model);
        }
    }
}
