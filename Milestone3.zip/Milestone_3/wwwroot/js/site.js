﻿$(document).ready(function () {
    let gameOver = false; // Flag to track if the game is over

    // Function to update the board by fetching the partial view and replacing the current board.
    function updateGameBoard() {
        $.get('/Minesweeper/GetBoardPartial', function (data) {
            $('.board').replaceWith(data);
        });
    }

    // Function that handles revealing a cell.
    // It sends an AJAX request to the server to reveal a cell at x, y coordinates.
    function revealCell(cellElement) {
        if (gameOver) return; // Don't allow further cell clicks when the game is over

        const x = $(cellElement).data('x');
        const y = $(cellElement).data('y');

        // Logging the coordinates to the web console for debugging purposes.
        console.log(`Revealing cell at coordinates: x=${x}, y=${y}`);

        $.ajax({
            url: '/Minesweeper/RevealCell',
            method: 'POST',
            data: {
                x: x,
                y: y
            },
            success: function (data) {
                // Update cell visuals based on data.cellData...
                const cell = $(cellElement);
                if (data.cellData.isRevealed) {
                    cell.addClass('revealed');

                    if (data.cellData.isMine) {
                        cell.html('<span>💣</span>');
                    } else {
                        if (data.cellData.neighboringMines > 0) {
                            cell.text(data.cellData.neighboringMines);
                        } else {
                            // If the clicked cell is empty, update the game board
                            updateGameBoard();
                        }
                    }
                }

                if (data.gameOver) {
                    if (data.playerWon) {
                        alert('Congratulations! You won!');
                    } else {
                        alert('Game Over! Better luck next time.');
                    }
                    // Prevent further clicks or add a mechanism to restart the game.
                    gameOver = true; // Set the game over flag
                    $(".cell").off("click");
                }

                // Update the timestamp at the foot of the page with the current date and time
                const timestamp = new Date().toLocaleString();
                $('.timestamp').text(`Last Cell Click: ${timestamp}`);
            }
        });
    }

    //Toggle flag on right-click
    $(document).on('contextmenu', '.cell', function (e) {
        e.preventDefault(); 
        const cellElement = this;

        // Toggle flag state.
        if ($(cellElement).hasClass('flagged')) {
            $(cellElement).removeClass('flagged');
            console.log('Flag removed');
            // Logic to remove flag, like updating backend (if you want to keep track of flags).
        } else {
            $(cellElement).addClass('flagged');
            console.log('Flag planted');
            // Logic to add flag, like updating backend (if you want to keep track of flags).
        }
    });

    // Disable left-click for flagged cells.
    $(document).on('click', '.cell.flagged', function (e) {
        e.stopPropagation();
    });

    // Bind the revealCell function to the click event of cells
    $(document).on('click', '.cell:not(.flagged)', function () {
        revealCell(this);
    });

    // Initial timestamp at the foot of the page
    const initialTimestamp = new Date().toLocaleString();
    $('.timestamp').text(`Last Cell Click: ${initialTimestamp}`);

    // Add a click event handler for the "Refresh Board" button
    $('#refreshButton').click(function () {
        // Call the updateGameBoard function when the button is clicked
        updateGameBoard();
    });
});
