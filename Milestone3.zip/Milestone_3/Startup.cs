﻿using CST_350_Milestone.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace CST_350_Milestone
{
    public class Startup
    {

        // Constructor that takes an IConfiguration. 
        // ASP.NET Core will inject the application's configuration into this constructor.
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; } // Represents a set of key/value application configuration properties.


        // This method gets called by the runtime and adds services to the DI container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Adds a default in-memory implementation of IDistributedCache.
            services.AddMemoryCache();

            // Register MinesweeperService and SecurityDAO as scoped services.
            services.AddScoped<MinesweeperService>();
            services.AddScoped<SecurityDAO>();

            // Uncommenting these would register the MinesweeperService as transient or singleton.
            //services.AddTransient<MinesweeperService>();
            //services.AddSingleton<MinesweeperService>();

           

            // Registers the application's DbContext and sets the connection string for it.
            services.AddDbContext<RegDBContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            // Adds session services. Configures the session cookie details.
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(20); // Increase session timeout to 20 minutes or adjust as needed.
                options.Cookie.HttpOnly = true; // Secure cookie setting.
                options.Cookie.IsEssential = true; // Session cookie is essential for the application.
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.Cookie.SameSite = SameSiteMode.Lax;
            });

            // Adds services for controllers and views.
            services.AddControllersWithViews();
            services.AddLogging(); // Add logging

        }

        // This method gets called by the runtime and configures the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // Shows developer-friendly error pages in development mode.
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // Handles exceptions by redirecting to an error page.
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts(); // Enforces HTTPS.
            }

            // Redirects HTTP requests to HTTPS.
            app.UseHttpsRedirection();

            // Enables the serving of static files from the wwwroot folder.
            app.UseStaticFiles();

            // Adds endpoint routing to the request pipeline.
            app.UseRouting();

            // Adds session middleware to the pipeline.
            app.UseSession();

            // Adds authorization middleware to the request pipeline.
            app.UseAuthorization();

            // Configures the application's endpoints.
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }
    }
}
